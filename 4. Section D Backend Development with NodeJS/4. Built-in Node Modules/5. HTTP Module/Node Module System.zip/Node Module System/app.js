const area = require("./circle");

console.log(area(4));