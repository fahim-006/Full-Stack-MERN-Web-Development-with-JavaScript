const area = r => 3.14 * r * r;
const circumference = r => 2 * 3.14 * r;
const message = "Hello World"


module.exports = area;

//console.log(module);

