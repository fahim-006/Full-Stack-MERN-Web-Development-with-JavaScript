const COMMENTS =
    [
        {
            dishId: 0,
            id: 0,
            rating: 5,
            comment: "Imagine all the eatables, living in conFusion!",
            author: "Shanto",
            date: "2018-10-16T17:57:28.556094Z"
        },
        {
            dishId: 0,
            id: 1,
            rating: 4,
            comment: "Sends anyone to heaven, I wish I could get my mother-in-law to eat it!",
            author: "Karim",
            date: "2017-09-05T17:57:28.556094Z"
        },
        {
            dishId: 0,
            id: 2,
            rating: 3,
            comment: "Eat it, just eat it!",
            author: "Moinul",
            date: "2019-02-13T17:57:28.556094Z"
        },
        {
            dishId: 0,
            id: 3,
            rating: 4,
            comment: "Ultimate, Reaching for the stars!",
            author: "Rahat",
            date: "2017-12-02T17:57:28.556094Z"
        },
        {
            dishId: 0,
            id: 4,
            rating: 2,
            comment: "It's your birthday, we're gonna party!",
            author: "Rony",
            date: "2019-12-02T17:57:28.556094Z"
        },
        {
            dishId: 1,
            id: 5,
            rating: 5,
            comment: "Imagine all the eatables, living in conFusion!",
            author: "Shanto",
            date: "2018-10-16T17:57:28.556094Z"
        },
        {
            dishId: 1,
            id: 6,
            rating: 4,
            comment: "Sends anyone to heaven, I wish I could get my mother-in-law to eat it!",
            author: "Karim",
            date: "2017-09-05T17:57:28.556094Z"
        },
        {
            dishId: 1,
            id: 7,
            rating: 3,
            comment: "Eat it, just eat it!",
            author: "Moinul",
            date: "2019-02-13T17:57:28.556094Z"
        },
        {
            dishId: 1,
            id: 8,
            rating: 4,
            comment: "Ultimate, Reaching for the stars!",
            author: "Rahat",
            date: "2017-12-02T17:57:28.556094Z"
        },
        {
            dishId: 1,
            id: 9,
            rating: 2,
            comment: "It's your birthday, we're gonna party!",
            author: "Rony",
            date: "2019-12-02T17:57:28.556094Z"
        },
        {
            dishId: 2,
            id: 10,
            rating: 5,
            comment: "Imagine all the eatables, living in conFusion!",
            author: "Shanto",
            date: "2018-10-16T17:57:28.556094Z"
        },
        {
            dishId: 2,
            id: 11,
            rating: 4,
            comment: "Sends anyone to heaven, I wish I could get my mother-in-law to eat it!",
            author: "Karim",
            date: "2017-09-05T17:57:28.556094Z"
        },
        {
            dishId: 2,
            id: 12,
            rating: 3,
            comment: "Eat it, just eat it!",
            author: "Moinul",
            date: "2019-02-13T17:57:28.556094Z"
        },
        {
            dishId: 2,
            id: 13,
            rating: 4,
            comment: "Ultimate, Reaching for the stars!",
            author: "Rahat",
            date: "2017-12-02T17:57:28.556094Z"
        },
        {
            dishId: 2,
            id: 14,
            rating: 2,
            comment: "It's your birthday, we're gonna party!",
            author: "Rony",
            date: "2019-12-02T17:57:28.556094Z"
        },
        {
            dishId: 3,
            id: 15,
            rating: 5,
            comment: "Imagine all the eatables, living in conFusion!",
            author: "Shanto",
            date: "2018-10-16T17:57:28.556094Z"
        },
        {
            dishId: 3,
            id: 16,
            rating: 4,
            comment: "Sends anyone to heaven, I wish I could get my mother-in-law to eat it!",
            author: "Karim",
            date: "2017-09-05T17:57:28.556094Z"
        },
        {
            dishId: 3,
            id: 17,
            rating: 3,
            comment: "Eat it, just eat it!",
            author: "Moinul",
            date: "2019-02-13T17:57:28.556094Z"
        },
        {
            dishId: 3,
            id: 18,
            rating: 4,
            comment: "Ultimate, Reaching for the stars!",
            author: "Rahat",
            date: "2017-12-02T17:57:28.556094Z"
        },
        {
            dishId: 3,
            id: 19,
            rating: 2,
            comment: "It's your birthday, we're gonna party!",
            author: "Rony",
            date: "2019-12-02T17:57:28.556094Z"
        }

    ];

export default COMMENTS;