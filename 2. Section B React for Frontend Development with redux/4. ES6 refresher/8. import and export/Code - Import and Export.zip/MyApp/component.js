export let a = 45;
export let str = "Bohubrihi";
export let obj = {
    name: "Rahat", age: 27
}

let arr = [1, 2, 3, 4]

export let hello = () => {
    console.log("Hello World");
}


export class Person {
    constructor() {
        this.name = "ABC"
    }
}

export default arr;