//import numbers, { str, a, hello, obj as xyz, Person } from './component.js';
import Application from './other.js';
import * as all from './component.js';

// console.log(str);

// hello();

// console.log(xyz);

// let person = new Person();

// console.log(person);

// let newApp = new Application("Some random text");

// console.log(newApp);

// console.log(numbers);

console.log(all.a);
console.log(all.str);
all.hello();
