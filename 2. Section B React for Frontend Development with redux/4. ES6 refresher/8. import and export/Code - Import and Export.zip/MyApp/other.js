class App {
    constructor(text) {
        this.text = text
    }

    printSomething() {
        console.log(this.text);
    }
}

export default App;