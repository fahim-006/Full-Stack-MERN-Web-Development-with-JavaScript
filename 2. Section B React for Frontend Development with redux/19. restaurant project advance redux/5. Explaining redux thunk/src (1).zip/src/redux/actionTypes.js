export const ADD_COMMENT = 'ADD_COMMENT';

export const LOAD_DISHES = 'LOAD_DISHES';
export const DISHES_LOADING = 'DISHES_LOADING';