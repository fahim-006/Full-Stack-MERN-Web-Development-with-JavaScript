import React, { Component } from 'react';

export default class BurgerBuilder extends Component {
    render() {
        return (
            <div>
                <p>Burger Builder</p>
            </div>
        )
    }
}