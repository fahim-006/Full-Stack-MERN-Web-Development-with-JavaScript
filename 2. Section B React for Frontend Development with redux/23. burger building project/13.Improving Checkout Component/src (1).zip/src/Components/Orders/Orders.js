import React from 'react';

const Orders = props => {
    return (
        <div>
            <p>Orders</p>
        </div>
    )
}

export default Orders;