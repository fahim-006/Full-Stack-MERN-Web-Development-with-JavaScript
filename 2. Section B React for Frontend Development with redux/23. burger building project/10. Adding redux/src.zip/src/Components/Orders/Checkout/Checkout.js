import React from 'react';

const Checkout = props => {
    return (
        <div>
            <p>Checkout</p>
        </div>
    )
}

export default Checkout;