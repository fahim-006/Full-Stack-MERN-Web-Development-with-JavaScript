import React from 'react';

const NewBook = props => {
    console.log(props);
    return (
        <div>
            <h1>New Book Entry</h1>
        </div>
    );
}

export default NewBook;