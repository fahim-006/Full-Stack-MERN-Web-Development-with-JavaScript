export const ADD_PLACE = 'ADD_PLACE';
export const DELETE_PLACE = 'DELETE_PLACE';

export const LOAD_PLACES = 'LOAD_PLACES';
export const SET_PLACES = 'SET_PLACES';

export const AUTHENTICATE_USER = 'AUTHENTICATE_USER';
export const REMOVE_TOKEN = 'REMOVE_TOKEN';