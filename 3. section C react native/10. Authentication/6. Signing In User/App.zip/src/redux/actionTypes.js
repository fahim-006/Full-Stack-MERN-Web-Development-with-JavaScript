export const ADD_PLACE = 'ADD_PLACE';
export const DELETE_PLACE = 'DELETE_PLACE';

export const LOAD_PLACES = 'LOAD_PLACES';
export const SET_PLACES = 'SET_PLACES';

export const TRY_SIGNUP = 'TRY_SIGNUP';
export const TRY_LOGIN = 'TRY_LOGIN';

export const AUTHENTICATE_USER = 'AUTHENTICATE_USER';