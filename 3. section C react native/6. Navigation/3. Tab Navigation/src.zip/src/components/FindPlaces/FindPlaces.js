import React from 'react';
import { View, Text } from 'react-native';
import MainComponent from '../../../src/MainComponent';

const FindPlaces = () => {
    return (
        <MainComponent />
    );
}

export default FindPlaces;