import React from 'react';
import { View, Text } from 'react-native';

const SharePlaces = () => {
    return (
        <View>
            <Text>Share Places</Text>
        </View>
    );
}

export default SharePlaces;