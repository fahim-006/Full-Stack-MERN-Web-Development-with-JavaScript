import React from 'react';
import { View, Text } from 'react-native';

const navigationTab = props => {
    return (
        <View>
            <Text>Navigation Tab</Text>
        </View>
    );
}

export default navigationTab;