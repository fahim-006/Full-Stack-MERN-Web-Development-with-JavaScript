import React from 'react';
import { View, Text } from 'react-native';

const DishDetailScreen = () => {
    return (
        <View><Text>DishDetail Screen</Text></View>
    )
}

export default DishDetailScreen;