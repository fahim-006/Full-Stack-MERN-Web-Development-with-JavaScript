import React from 'react';
import HomeScreen from './screens/HomeScreen';
import MenuScreen from './screens/MenuScreen';
import DishDetailScreen from './screens/DishDetailScreen';
import { View, Text } from 'react-native';

const AppNavigator = () => {
    return (
        <HomeScreen />
    )
}

export default AppNavigator;