import React from 'react';
import { View, Text } from 'react-native';

const MenuScreen = () => {
    return (
        <View><Text>Menu Screen</Text></View>
    )
}

export default MenuScreen;