import React from 'react';
import { View, Text } from 'react-native';

const AppNavigator = () => {
    return (
        <View><Text>AppNavigator</Text></View>
    )
}

export default AppNavigator;