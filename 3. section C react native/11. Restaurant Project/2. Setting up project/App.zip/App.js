
import React from 'react';
import AppNavigator from './app/AppNavigator';


export default function App() {
  return (
    <AppNavigator />
  );
}

