import React from 'react';
import { View, Modal, Image, Text, Button } from 'react-native';

const PlaceDetail = props => {
    return (<Modal>
        <View>
            <Text></Text>
            <View>
                <Button />
            </View>
        </View>
    </Modal>)
}

export default PlaceDetail;