import React from 'react';
import { View, Button } from 'react-native';

const PickImage = props => {
    return (
        <View>
            <Button title="Pick an Image" />
        </View>
    )
}

export default PickImage;